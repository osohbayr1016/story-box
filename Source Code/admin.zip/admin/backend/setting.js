module.exports = {
  "_id": "6891c8cabe6154302627a96a",
  "currency": {
    "name": "USD",
    "symbol": "$",
    "countryCode": "USA",
    "currencyCode": "USD",
    "isDefault": true
  },
  "storage": {
    "awsS3": false,
    "digitalOcean": false,
    "local": true
  },
  "android": {
    "google": {
      "interstitial": "android_interstitial_id",
      "native": "android_native_id",
      "reward": "ca-app-pub-3940256099942544/5224354917"
    }
  },
  "ios": {
    "google": {
      "interstitial": "ios_interstitial_id",
      "native": "ios_native_id",
      "reward": "ca-app-pub-3940256099942544/1712485313"
    }
  },
  "googlePlaySwitch": true,
  "stripeSwitch": true,
  "stripePublishableKey": "pk_test_51PnZpxCgbHHJtm7RPVLjX28kr3mQGhHobJ1WaCGKBNh9cWZKLJJdu5f1EltNyjNVzcdQSYgJfizsbbC2RP987rTE00pdwG8KyZ",
  "stripeSecretKey": "sk_test_51PnZpxCgbHHJtm7RDtzCYMoBhYZRAzexHtTEEhQW3AWcZkxMIoDiRq5gv9IaLrgkhUOoJN0oqpA86S7LTpCo47Sy00in4p6AjQ",
  "razorPaySwitch": true,
  "razorPayId": "RAZOR PAY ID",
  "razorSecretKey": "rzp_test_SjZz9HC7RGCfCb",
  "flutterWaveId": "FLUTTER WAVE Id",
  "flutterWaveSwitch": true,
  "privacyPolicyLink": "https://www.termsfeed.com/live/ae4296b0-36ce-4c8d-82ee-8400ae94f581",
  "termsOfUsePolicyLink": "https://www.termsfeed.com/live/ae4296b0-36ce-4c8d-82ee-8400ae94f581",
  "durationOfShorts": 180,
  "minCoinForCashOut": 0,
  "minWithdrawalRequestedCoin": 0,
  "referralRewardCoins": 40,
  "watchingVideoRewardCoins": 100,
  "commentingRewardCoins": 100,
  "likeVideoRewardCoins": 100,
  "loginRewardCoins": 5000,
  "maxAdPerDay": 6,
  "isGoogle": false,
  "privateKey": {
    "type": "service_account",
    "project_id": "storybox-abc06",
    "private_key_id": "e991ea8313823ce9ec2e12ea4feb63241687a6f53707",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCtZlYPZUZcckCe\n3Jo29rIqCQSdD6sJ8VnAD8EMTZVFYpl3KeyFwqmIJ0XslSQAVDf0yoYKagOinY9R\neX9rzv4+Hezi/5Ef+TeYohRVL676kBC7mu7DyKmKIn4AmSqtAaW3izNXKw+DeuWF\nyNQAMITFtsjS9Wza2lCBaWK1JteEjzOGtiFaJTorMJlZdqCZG3qx4vqTf9L2L9IK\nCa99bntyTXfOb8RBd5wHrqkXNv/MUOyRf4evSedHBLlGgWpfTPdwdJEWrQaynP+r\nD3mRNVphfsQowY3S3k+uYWqcgbF/MO3KwTp/bYK7ZyLMJ8gLyDBOlScaPxE3xb7c\n+7YSgTGDAgMBAAECggEAIz1kChbz+L/DgEWnFbqHNOHGTUEs6oVhTxYkjqKJzqMe\nO0iK6BhKqgAJRu58dZCoGpi6Kw2mlXrd8Jn3mmpj4y3jwbJcxRm6AcwWw8VAE24J\n6IaxNZrnUcp2vxphwO1Px4CDu5hlu7vTP6Az7aHuqdve7niwWb36lIJdbCFrtWWr\nN3u93vzGviluW3Ev7TgSu3m71JZJKEDVp9xN5gHwKvUleI2CBDd+f1j98+pBw6oy\nxvJs6ZNut/biRB2DwOn9gNf1NHhNOMe5EtvzRq/fdcETwmlN6urJfUarGEYaQQIN\nygX2wNO9lXmZ+O4Uru4STzsbN3uQPE4vKS670tqr4QKBgQDeoaL0a5edIxofBZ6B\nQ2Ohe+LLdqFQmd3HhIlJ1gHfOY6ejadxGzJe38HFtCKat27u209Xz9eOWFIUhQl4\nAq0cFXq8dohGiTYHTueR5PIlJ/aG4LVQpEoo8XRYND7r/c22zVeBSpHBH/pcppwm\nZTZ3i7gblrVrp34dxycC/t04UwKBgQDHY66lBxrQRmrFCmksdGnfBjWNzorxVJMf\nvzjS78sOpO69ASSwOKK25xWrMAaK/HknL+O623/zMJgJqgry6TWT6lV+M4SSUaHT\nnjxuFwfLRLVSOPpC58tw/HdvL7+PpaG+Vx7c/9ad0Gmm03P1gpyxLrPdn25b2tkQ\nIp1YCU88EQKBgQC/z2MmUsx9hhCrSZwWoojkSGhOBBdX6jk5/OaLxuY1/NDzqffp\naxUqyH2aaGioBAJ/qFPjxB5jdZTCORy/WQ7sc1UbqsQegXkbMtAw0qANgzDTZCbT\nI7kBLYaft+O+Tx09sg0CR8zsJzD9Qk6mhe03chldK6uC5PuzjDIAUrUmIQKBgChP\nBaKFMi2C3tjgxuxeyHx24+K8K6ioIWocnV8/bPyT6VO6ZHFfsb1qMB5AgkIc0l1S\nuCYxc8d1PndNshLzhIpXqFrwDVALQrzmU28qJsA4LrPloupds+ouj/KhY4elw3IY\naLvi2L9kv8cjHmE2u3iyaVhXf9cAAjvZ05dVongRAoGAMVBWD5neVXqi1QzcEBvl\nnw5WbKnwDZJ1BVBrSs/NapTr9dgataPdrzGwymKR4Hage9r2R/1G/CABffmMdg+v\nqXx6+YZUfoA+GWWcJKj+2tQPE+d2MBK6vXtmoLZWIlp9FvBBdVHJwcR24HlQ3Ze3\nl2kIvcMLjq+Sre8DERrQVv4=\n-----END PRIVATE KEY-----\n",
    "client_email": "firebase-adminsdk-pyfdy@storybox-abc06.iam.gserviceaccount.com",
    "client_id": "11016151632179759964335",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-pyfdy%40storybox-abc06.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
  },
  "createdAt": "2024-10-21T11:47:03.908Z",
  "updatedAt": "2025-06-13T10:49:15.218Z",
  "freeEpisodesForNonVip": 2,
  "contactEmail": "support@example.com",
  "resendApiKey": "RESEND API KEY",
  "awsAccessKey": "awsAccessKey",
  "awsBucketName": "awsBucketName",
  "awsEndpoint": "https://s3.region.amazonaws.com",
  "awsHostname": "https://bucket-name.s3.region.amazonaws.com",
  "awsRegion": "awsRegion",
  "awsSecretKey": "awsSecretKey",
  "doAccessKey": "doAccessKey",
  "doBucketName": "doBucketName",
  "doEndpoint": "https://doBucketName.region.digitaloceanspaces.com",
  "doHostname": "https://region.digitaloceanspaces.com",
  "doRegion": "doRegion",
  "doSecretKey": "doSecretKey"
};