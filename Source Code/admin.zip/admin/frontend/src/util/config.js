export const baseURL = "";
export const secretKey = "";
export const projectName = "";
