import 'package:get/get.dart';

class MyListController extends GetxController {}
